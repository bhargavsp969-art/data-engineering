# Databricks notebook source
df = spark.read.option("header","true").csv("/Volumes/dataengineer/ingestion/netflix/netflix_titles.csv")
display(df)

# COMMAND ----------

#Import Libraries
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime
import time

# COMMAND ----------

#Start Processing Timer
start_time = time.time()

# COMMAND ----------

#: Read CSV File
file_path = "/Volumes/dataengineer/ingestion/netflix/netflix_titles.csv"

df = spark.read \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .csv(file_path)

display(df)

# COMMAND ----------

#: Records Received
records_received = df.count()

print("Records Received :", records_received)

# COMMAND ----------

#Generate Batch ID
batch_id = "BATCH_" + datetime.now().strftime("%Y%m%d%H%M%S")

print(batch_id)

# COMMAND ----------

#Add Audit Columns
df = df.withColumn("batch_id", lit(batch_id)) \
       .withColumn("source_layer", lit("Bronze")) \
       .withColumn("processing_timestamp", current_timestamp()) \
       .withColumn("record_status", lit("Received"))

# COMMAND ----------

#Remove Duplicate Records
before_duplicates = df.count()

df = df.dropDuplicates(["show_id"])

after_duplicates = df.count()

duplicates_removed = before_duplicates - after_duplicates

print("Duplicates Removed :", duplicates_removed)

# COMMAND ----------

#Handle Null Values
df = df.fillna({
    "director": "Unknown",
    "cast": "Unknown",
    "country": "Unknown",
    "rating": "Not Rated",
    "date_added": "Unknown"
})

# COMMAND ----------

#Standardize Text Values
df = df.withColumn("title", initcap(col("title"))) \
       .withColumn("type", upper(col("type"))) \
       .withColumn("country", upper(col("country"))) \
       .withColumn("rating", upper(col("rating")))

# COMMAND ----------

#Trim Extra Spaces
string_columns = ["title","director","cast","country","rating","listed_in"]

for column in string_columns:
    df = df.withColumn(column, trim(col(column)))

# COMMAND ----------

#Apply Business Rule
current_year = datetime.now().year

valid_df = df.filter(col("release_year") <= current_year)

invalid_df = df.filter(col("release_year") > current_year)


# COMMAND ----------

#Correct Data Types
df = df.withColumn(
    "release_year",
    expr("try_cast(release_year AS INT)")
)

# COMMAND ----------

#Add Record Status
valid_df = valid_df.withColumn(
    "record_status",
    lit("VALID")
)

# COMMAND ----------

#Display Final Silver Data
display(valid_df)

# COMMAND ----------

#

# COMMAND ----------

#Null Value Percentage Validation
import builtins
from pyspark.sql.functions import col, when, count

total_records = df.count()

null_percentage = []

for c in df.columns:
    null_count = df.filter(col(c).isNull()).count()
    percentage = builtins.round((null_count / total_records) * 100, 2)

    null_percentage.append((c, null_count, percentage))

null_report = spark.createDataFrame(
    null_percentage,
    ["Column_Name", "Null_Count", "Null_Percentage"]
)

display(null_report)

# COMMAND ----------



# COMMAND ----------

#Duplicate Records Validation
duplicate_df = df.groupBy("show_id") \
                 .count() \
                 .filter(col("count") > 1)

duplicate_count = duplicate_df.count()

print("Duplicate Records :", duplicate_count)

display(duplicate_df)

# COMMAND ----------



# COMMAND ----------

#Invalid Records Validation
from datetime import datetime

current_year = datetime.now().year

invalid_records = df.filter(
    col("release_year") > current_year
)

print("Invalid Records :", invalid_records.count())

display(invalid_records)

# COMMAND ----------

#Data Type Mismatch Validation
expected_schema = {
    "show_id":"string",
    "type":"string",
    "title":"string",
    "director":"string",
    "cast":"string",
    "country":"string",
    "date_added":"string",
    "release_year":"int",
    "rating":"string",
    "duration":"string",
    "listed_in":"string",
    "description":"string"
}

for field in df.schema.fields:

    expected = expected_schema.get(field.name)

    actual = field.dataType.simpleString()

    if expected == actual:
        print(field.name," : PASS")
    else:
        print(field.name," : FAIL")

# COMMAND ----------

#Mandatory Field Validation
mandatory_columns = [
    "show_id",
    "type",
    "title"
]

for c in mandatory_columns:

    count = df.filter(col(c).isNull()).count()

    print(c,"Null Count :",count)

# COMMAND ----------

#Referential Integrity Check
print("Referential Integrity Check : PASS")

print("No Parent Table Available")

# COMMAND ----------

#Business Rule Validation
business_rule1 = df.filter(
    col("release_year") > current_year
)

display(business_rule1)

# COMMAND ----------

#Validation Summary Report
# Count mandatory field violations
mandatory_columns = ["show_id", "type", "title"]
mandatory_violation_count = 0
for column_name in mandatory_columns:
    mandatory_violation_count += df.filter(col(column_name).isNull()).count()

# Count business rule failures (from Cell 25)
business_rule1 = df.filter(col("release_year") > datetime.now().year)
business_failures = business_rule1.count()

validation_summary = spark.createDataFrame(

[(
total_records,
duplicate_count,
invalid_records.count(),
mandatory_violation_count,
business_failures
)],

[
"Total_Records",
"Duplicate_Records",
"Invalid_Records",
"Mandatory_Field_Violations",
"Business_Rule_Failures"
]
)

display(validation_summary)


# COMMAND ----------

#Validation Status
if (
duplicate_count==0 and
invalid_records.count()==0 and
mandatory_violation_count==0 and
business_failures==0
):

    validation_status="PASS"

else:

    validation_status="FAIL"

print("Validation Status :",validation_status)

# COMMAND ----------

#Invalid Records
from pyspark.sql.functions import lit

invalid_records = invalid_records.withColumn(
    "reject_reason",
    lit("Invalid Release Year")
)

display(invalid_records)



# COMMAND ----------

#Rejected Records
mandatory_columns = ["show_id", "type", "title"]
mandatory_violation = df.filter(
    col("show_id").isNull() | col("type").isNull() | col("title").isNull()
)

rejected_records = mandatory_violation.withColumn(
    "reject_reason",
    lit("Mandatory Field Missing")
)

display(rejected_records)

# COMMAND ----------

#Data Quality Failures
duplicate_records = df.groupBy("show_id") \
    .count() \
    .filter(col("count") > 1)

dq_failures = duplicate_records.withColumn(
    "reject_reason",
    lit("Duplicate Record")
)

display(dq_failures)

# COMMAND ----------

#Combine All Rejected Records
rejected_df = invalid_records.unionByName(
    rejected_records,
    allowMissingColumns=True
)

display(rejected_df)

# COMMAND ----------

#Save Rejected Records Table
rejected_df.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("dataengineer.default.rejected_records")

print("Rejected Records Table Created Successfully")

# COMMAND ----------

#Save Silver Delta Table
valid_df.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("dataengineer.default.silver_netflix")

print("Silver Delta Table Created Successfully")


# COMMAND ----------

#Read Silver Delta Table
silver_df = spark.read \
    .format("delta") \
    .table("dataengineer.default.silver_netflix")

display(silver_df)

# COMMAND ----------

#Records Processed
records_processed = silver_df.count()

print("Records Processed :", records_processed)

# COMMAND ----------

#Records Rejected
records_rejected = rejected_df.count()

print("Records Rejected :", records_rejected)

# COMMAND ----------

#. Validation Failures
validation_failures = (
    duplicate_count +
    invalid_records.count() +
    mandatory_violation.count()
)

print("Validation Failures :", validation_failures)


# COMMAND ----------

#Validation Report
validation_report = spark.createDataFrame(

[(
records_received,
records_processed,
records_rejected,
duplicate_count,
invalid_records.count(),
mandatory_violation.count(),
business_failures
)],

[
"Records_Received",
"Records_Processed",
"Records_Rejected",
"Duplicate_Records",
"Invalid_Records",
"Mandatory_Field_Violations",
"Business_Rule_Failures"
]
)

display(validation_report)

# COMMAND ----------

#Save Validation Report
validation_report.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("dataengineer.default.validation_report")


# COMMAND ----------

#Audit Report
audit_report = valid_df.select(

"batch_id",
"source_layer",
"processing_timestamp",
"record_status"

)

display(audit_report)


# COMMAND ----------

#Save Audit Report
audit_report.write \
.format("delta") \
.mode("overwrite") \
.saveAsTable("dataengineer.default.audit_report")

# COMMAND ----------

#Verify All Silver Tables
print("Silver Table")
display(spark.read.format("delta").table("dataengineer.default.silver_netflix"))

print("Rejected Records")
display(spark.read.format("delta").table("dataengineer.default.rejected_records"))

print("Validation Report")
display(spark.read.format("delta").table("dataengineer.default.validation_report"))

print("Audit Report")
display(spark.read.format("delta").table("dataengineer.default.audit_report"))

# COMMAND ----------

#Processing End Time
import builtins
end_time = time.time()

processing_duration = builtins.round(end_time - start_time, 2)

print("Processing Duration :", processing_duration, "Seconds")

# COMMAND ----------

#Records Received
print("Records Received :", records_received)

# COMMAND ----------

#Records Processed
records_processed = valid_df.count()

print("Records Processed :", records_processed)

# COMMAND ----------

#Records Rejected
records_rejected = rejected_df.count()

print("Records Rejected :", records_rejected)

# COMMAND ----------

#Validation Failures
validation_failures = (
    duplicate_count +
    invalid_records.count() +
    mandatory_violation.count() +
    business_failures
)

print("Validation Failures :", validation_failures)

# COMMAND ----------

#Determine Job Status
if validation_failures == 0:
    job_status = "SUCCESS"
else:
    job_status = "FAILED"

print("Job Status :", job_status)

# COMMAND ----------

#Logging Report
logging_report = spark.createDataFrame(
[
(
records_received,
records_processed,
records_rejected,
validation_failures,
processing_duration,
job_status
)
],
[
"Records_Received",
"Records_Processed",
"Records_Rejected",
"Validation_Failures",
"Processing_Duration_Seconds",
"Job_Status"
]
)

display(logging_report)


# COMMAND ----------

#Save Logging Report
logging_report.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("dataengineer.default.logging_report")

print("Logging Report Saved Successfully")

# COMMAND ----------

#Audit Report
audit_report = valid_df.withColumn(
    "batch_id", lit(batch_id)
).withColumn(
    "source_layer", lit("Bronze")
).withColumn(
    "processing_timestamp", current_timestamp()
).withColumn(
    "record_status", lit("VALID")
)

display(audit_report)

# COMMAND ----------

#Save Audit Report
audit_report.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("dataengineer.default.audit_report_final")

print("Audit Report Saved Successfully")

# COMMAND ----------

#Execution Log
execution_log = spark.createDataFrame(
[
(
batch_id,
"Bronze",
records_received,
records_processed,
records_rejected,
validation_failures,
processing_duration,
job_status,
datetime.now()
)
],
[
"Batch_ID",
"Source_Layer",
"Records_Received",
"Records_Processed",
"Records_Rejected",
"Validation_Failures",
"Processing_Duration",
"Job_Status",
"Execution_Time"
]
)

display(execution_log)

# COMMAND ----------

#Save Execution Log
execution_log.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("dataengineer.default.execution_log")

print("Execution Log Saved Successfully")

# COMMAND ----------

#Verify All Deliverables
print("Silver Delta Table")
display(spark.read.format("delta").table("dataengineer.default.silver_netflix"))

print("Rejected Records Table")
display(spark.read.format("delta").table("dataengineer.default.rejected_records"))

print("Validation Report")
display(spark.read.format("delta").table("dataengineer.default.validation_report"))

print("Audit Report")
display(spark.read.format("delta").table("dataengineer.default.audit_report_final"))

print("Logging Report")
display(spark.read.format("delta").table("dataengineer.default.logging_report"))

print("Execution Log")
display(spark.read.format("delta").table("dataengineer.default.execution_log"))

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

