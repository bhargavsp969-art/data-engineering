# Databricks notebook source
\++\9#/Volumes/dataengineer/ingestion/netflix
df = spark.read.option("header","true").csv("/Volumes/dataengineer/ingestion/netflix/netflix_titles.csv")
df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC # Import Libraries

# COMMAND ----------

from pyspark.sql.functions import *
from datetime import datetime
import hashlib
import os

# COMMAND ----------

# MAGIC %md
# MAGIC #  Define File Path
# MAGIC

# COMMAND ----------


file_path = "/Volumes/dataengineer/ingestion/netflix/netflix_titles.csv"

# COMMAND ----------

# MAGIC %md
# MAGIC # Pipeline Start Time
# MAGIC

# COMMAND ----------

pipeline_start_time = datetime.now()

print("Pipeline Start Time:", pipeline_start_time)

# COMMAND ----------

# MAGIC %md
# MAGIC # Source File Availability Validation
# MAGIC

# COMMAND ----------

display(dbutils.fs.ls("/Volumes/dataengineer/ingestion/netflix/"))

# COMMAND ----------

# MAGIC %md
# MAGIC # File Format Validation
# MAGIC

# COMMAND ----------

file_format = file_path.split(".")[-1]

if file_format.lower() == "csv":
    print("Valid CSV File")
else:
    raise Exception("Invalid File Format")

# COMMAND ----------

# MAGIC %md
# MAGIC # Read Source File

# COMMAND ----------

df = spark.read \
    .option("header", True) \
    .option("inferSchema", True) \
    .csv(file_path)

df.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC # File Size Validation
# MAGIC

# COMMAND ----------

record_count = df.count()

if record_count > 0:
    print("File Contains Data")
else:
    raise Exception("Empty File")

# COMMAND ----------

# MAGIC %md
# MAGIC # Source File Name Capture
# MAGIC

# COMMAND ----------

file_name = file_path.split("/")[-1]

print(file_name)

# COMMAND ----------

# MAGIC %md 
# MAGIC # Batch ID Capture
# MAGIC

# COMMAND ----------

batch_id = "BATCH_" + datetime.now().strftime("%Y%m%d%H%M%S")

print(batch_id)

# COMMAND ----------

# MAGIC %md
# MAGIC # Processing Date Capture
# MAGIC

# COMMAND ----------

processing_date = datetime.now().date()

print(processing_date)

# COMMAND ----------

# MAGIC %md
# MAGIC # Ingestion Timestamp Capture
# MAGIC

# COMMAND ----------

df = df.withColumn(
    "ingestion_timestamp",
    current_timestamp()
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Add Source File Name Column
# MAGIC

# COMMAND ----------

df = df.withColumn(
    "source_file_name",
    lit(file_name)
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Add Batch ID Column
# MAGIC

# COMMAND ----------

df = df.withColumn(
    "batch_id",
    lit(batch_id)
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Add Processing Date Column
# MAGIC

# COMMAND ----------

df = df.withColumn(
    "processing_date",
    current_date()
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Display Data After Metadata Addition
# MAGIC

# COMMAND ----------

df.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC # Empty File Validation
# MAGIC

# COMMAND ----------

if df.count() == 0:
    raise Exception("File is Empty")
else:
    print("File Passed Empty File Validation")

# COMMAND ----------

# MAGIC %md
# MAGIC # Corrupt File Validation
# MAGIC

# COMMAND ----------

try:
    df = spark.read \
        .option("header", True) \
        .csv(file_path)

    print("File is Not Corrupt")

except Exception as e:
    raise Exception(f"Corrupt File: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Duplicate File Validation
# MAGIC

# COMMAND ----------

file_hash = hashlib.md5(file_name.encode()).hexdigest()

print("File Hash:", file_hash)

# COMMAND ----------

# MAGIC %md
# MAGIC # Schema Validation

# COMMAND ----------

expected_columns = [
    'show_id',
    'type',
    'title',
    'director',
    'cast',
    'country',
    'date_added',
    'release_year',
    'rating',
    'duration',
    'listed_in',
    'description'
]

if df.columns[:12] == expected_columns:
    print("Schema Validation Passed")
else:
    raise Exception("Schema Validation Failed")

# COMMAND ----------

# MAGIC %md
# MAGIC # Total Records Read
# MAGIC

# COMMAND ----------

total_records = df.count()

print("Total Records Read:", total_records)

# COMMAND ----------

# MAGIC %md
# MAGIC # Processing Status
# MAGIC

# COMMAND ----------

status = "SUCCESS"

print(status)

# COMMAND ----------

# MAGIC %md
# MAGIC # Audit Information Generation
# MAGIC

# COMMAND ----------

audit_data = [(
    batch_id,
    file_name,
    total_records,
    str(processing_date),
    status
)]

audit_columns = [
    "batch_id",
    "file_name",
    "record_count",
    "processing_date",
    "status"
]

audit_df = spark.createDataFrame(
    audit_data,
    audit_columns
)

audit_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC # Load Raw Data to Landing Layer

# COMMAND ----------

landing_path = "/Volumes/dataengineer/landing/netflix/"

# COMMAND ----------

# MAGIC %md
# MAGIC # Pipeline End Time
# MAGIC

# COMMAND ----------

pipeline_end_time = datetime.now()

print("Pipeline End Time:", pipeline_end_time)

# COMMAND ----------

# MAGIC %md
# MAGIC # Execution Log
# MAGIC

# COMMAND ----------

print("====================================")
print("PIPELINE EXECUTION LOG")
print("====================================")

print("Start Time :", pipeline_start_time)
print("End Time   :", pipeline_end_time)
print("File Name  :", file_name)
print("Batch ID   :", batch_id)
print("Records    :", total_records)
print("Status     :", status)

print("====================================")

# COMMAND ----------

