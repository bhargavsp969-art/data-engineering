# Databricks notebook source
# MAGIC %md
# MAGIC # Load Data From Ingestion Layer
# MAGIC

# COMMAND ----------

df = spark.read.option("header","true").csv("/Volumes/dataengineer/ingestion/netflix/netflix_titles.csv")
display(df)

# COMMAND ----------

# DBTITLE 1,Cell 3
source_path = "/Volumes/dataengineer/ingestion/netflix/netflix_titles.csv"

ingestion_df = spark.read \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .csv(source_path)

source_record_count = ingestion_df.count()

print("Source Record Count:", source_record_count)

# COMMAND ----------

#Import Libraries
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime
import time

# COMMAND ----------

#Start Timer
start_time = time.time()

# COMMAND ----------

#Read Data from Ingestion Layer
file_path = "/Volumes/dataengineer/ingestion/netflix/netflix_titles.csv"

df = spark.read \
          .option("header", "true") \
          .option("inferSchema", "true") \
          .csv(file_path)

display(df)

# COMMAND ----------

#Source Record Count
source_record_count = df.count()

print("Source Record Count :", source_record_count)

# COMMAND ----------

#Generate Batch ID
batch_id = "BATCH_" + datetime.now().strftime("%Y%m%d%H%M%S")


# COMMAND ----------

#Add Audit Columns
bronze_df = df.withColumn("batch_id", lit(batch_id)) \
              .withColumn("load_timestamp", current_timestamp()) \
              .withColumn("processing_date", current_date()) \
              .withColumn("source_system", lit("Netflix CSV")) \
              .withColumn("created_timestamp", current_timestamp())

# COMMAND ----------

#Total Record Validation
total_records = bronze_df.count()

print("Total Records :", total_records)

# COMMAND ----------

#Null Count Validation
from pyspark.sql.functions import col, sum

null_counts = bronze_df.select([
    sum(col(c).isNull().cast("int")).alias(c)
    for c in bronze_df.columns
])

display(null_counts)

# COMMAND ----------

#Duplicate Count Validation
duplicate_count = bronze_df.groupBy("show_id") \
                           .count() \
                           .filter(col("count") > 1) \
                           .count()

print("Duplicate Records :", duplicate_count)

# COMMAND ----------

#Schema Validation
expected_schema = [
    "show_id",
    "type",
    "title",
    "director",
    "cast",
    "country",
    "date_added",
    "release_year",
    "rating",
    "duration",
    "listed_in",
    "description"
]

actual_schema = bronze_df.columns[:12]

if expected_schema == actual_schema:
    schema_status = "PASS"
else:
    schema_status = "FAIL"

print("Schema Validation :", schema_status)


# COMMAND ----------

#Mandatory Column Validation
mandatory_columns = [
    "show_id",
    "type",
    "title"
]

for column in mandatory_columns:
    count = bronze_df.filter(col(column).isNull()).count()
    print(column, "Null Count :", count)

# COMMAND ----------

#Target Record Count
target_record_count = bronze_df.count()

print("Target Record Count :", target_record_count)


# COMMAND ----------

#Validation Report
validation_report = spark.createDataFrame(
[
(
source_record_count,
target_record_count,
total_records,
duplicate_count,
schema_status
)
],
[
"Source_Record_Count",
"Target_Record_Count",
"Total_Records",
"Duplicate_Records",
"Schema_Status"
]
)

display(validation_report)

# COMMAND ----------

#: Audit Report
audit_report = bronze_df.select(
    "batch_id",
    "load_timestamp",
    "processing_date",
    "source_system",
    "created_timestamp"
)

display(audit_report.limit(10))


# COMMAND ----------

#Processing Duration
end_time = time.time()

import builtins
processing_duration = builtins.round(end_time - start_time, 2)

print("Processing Time :", processing_duration,"Seconds")

# COMMAND ----------

#Job Status
if source_record_count == target_record_count and duplicate_count == 0:
    job_status = "SUCCESS"
else:
    job_status = "FAILED"

print("Job Status :", job_status)

# COMMAND ----------

#Execution Log
execution_log = spark.createDataFrame(
[
(
batch_id,
source_record_count,
target_record_count,
processing_duration,
job_status
)
],
[
"Batch_ID",
"Source_Record_Count",
"Target_Record_Count",
"Processing_Duration",
"Job_Status"
]
)

display(execution_log)

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

