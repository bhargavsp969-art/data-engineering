# Databricks notebook source
df = spark.read.option("header","true").csv("/Volumes/dataengineer/ingestion/netflix/netflix_titles.csv")
display(df)

# COMMAND ----------

#Import Libraries
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime
import time

# COMMAND ----------

#Start Timer
start_time = time.time()

# COMMAND ----------

#Read CSV File
file_path="/Volumes/dataengineer/ingestion/netflix/netflix_titles.csv"

df=spark.read \
.option("header","true") \
.option("inferSchema","true") \
.csv(file_path)

display(df)


# COMMAND ----------

#Source Record Count
source_records=df.count()

print("Source Records :",source_records)

# COMMAND ----------

#Generate Batch ID
batch_id="BATCH_"+datetime.now().strftime("%Y%m%d%H%M%S")

print(batch_id)

# COMMAND ----------

#Add Audit Columns
gold_df=df.withColumn("batch_id",lit(batch_id)) \
.withColumn("aggregation_date",current_date()) \
.withColumn("processing_timestamp",current_timestamp()) \
.withColumn("gold_load_status",lit("IN_PROGRESS"))



# COMMAND ----------

#Verify Audit Columns
display(gold_df)

# COMMAND ----------

#Standardize Column Names
for column in gold_df.columns:
    gold_df=gold_df.withColumnRenamed(
        column,
        column.lower().replace(" ","_")
    )

# COMMAND ----------

#Remove Duplicate Records
gold_df=gold_df.dropDuplicates(["show_id"])

print("Records After Removing Duplicates :",gold_df.count())


# COMMAND ----------

#Handle Null Values
gold_df=gold_df.fillna({

"director":"Unknown",

"cast":"Unknown",

"country":"Unknown",

"rating":"Not Rated",

"date_added":"Unknown"

})

# COMMAND ----------

#Standardize Text Values
gold_df=gold_df.withColumn(
"title",
initcap(col("title"))
)

gold_df=gold_df.withColumn(
"type",
upper(col("type"))
)

gold_df=gold_df.withColumn(
"country",
upper(col("country"))
)

gold_df=gold_df.withColumn(
"rating",
upper(col("rating"))
)

# COMMAND ----------

#Trim Spaces
string_columns=[
"title",
"director",
"cast",
"country",
"rating",
"listed_in"
]

for c in string_columns:
    gold_df=gold_df.withColumn(c,trim(col(c)))

# COMMAND ----------

#Correct Data Types
gold_df=gold_df.withColumn(
"release_year",
col("release_year").cast(IntegerType())
)

# COMMAND ----------

#Filter Valid Records
current_year=datetime.now().year

gold_df=gold_df.filter(
col("release_year")<=current_year
)


# COMMAND ----------

#Create Business Category
gold_df=gold_df.withColumn(

"content_category",

when(col("type")=="MOVIE","Movie")

.when(col("type")=="TV SHOW","TV Show")

.otherwise("Other")

)


# COMMAND ----------

#Create Release Decade
gold_df=gold_df.withColumn(

"release_decade",

concat(

floor(col("release_year")/10)*10,

lit("s")

)

)

# COMMAND ----------

#Extract Added Year
gold_df=gold_df.withColumn(

"added_year",

year(to_date(col("date_added"),"MMMM d, yyyy"))

)

# COMMAND ----------

#Create Duration Category
gold_df=gold_df.withColumn(

"duration_category",

when(col("duration").contains("min"),"Movie")

.when(col("duration").contains("Season"),"TV Show")

.otherwise("Unknown")

)


# COMMAND ----------

#Read Silver Table
from pyspark.sql.functions import *

silver_df = spark.read.format("delta").table("dataengineer.default.silver_netflix")

silver_df.display()


# COMMAND ----------

#Create Business KPIs
total_sales = silver_df.agg(
    round(sum("total_amount"),2).alias("Total_Sales")
)



# COMMAND ----------

total_sales = silver_df.agg(
    round(sum("total_amount"),2).alias("Total_Sales")
)

# COMMAND ----------

total_orders = silver_df.select(
    countDistinct("order_id").alias("Total_Orders")
)

# COMMAND ----------

total_customers = silver_df.select(
    countDistinct("customer_id").alias("Total_Customers")
)

# COMMAND ----------

average_order_value = silver_df.select(
    round(avg("total_amount"),2).alias("Average_Order_Value")
)

# COMMAND ----------

quantity_sold = silver_df.select(
    sum("quantity").alias("Total_Quantity")
)

# COMMAND ----------

#Business KPI table
business_kpi = silver_df.agg(
    count("show_id").alias("Total_Content"),
    countDistinct("type").alias("Content_Types"),
    countDistinct("country").alias("Total_Countries"),
    countDistinct("rating").alias("Total_Ratings"),
    round(avg("release_year"),0).alias("Avg_Release_Year"),
    countDistinct("director").alias("Total_Directors")
)

business_kpi.display()


# COMMAND ----------

#Save KPI Table
business_kpi.write.mode("overwrite").format("delta").saveAsTable("gold_business_kpi")

# COMMAND ----------

category_summary = silver_df.groupBy("type").agg(
    count("show_id").alias("Content_Count"),
    countDistinct("country").alias("Countries"),
    countDistinct("rating").alias("Ratings"),
    round(avg("release_year"),0).alias("Avg_Release_Year")
)

category_summary.display()

# COMMAND ----------

country_summary = silver_df.groupBy("country").agg(
    count("show_id").alias("Content_Count"),
    countDistinct("type").alias("Content_Types"),
    countDistinct("rating").alias("Ratings")
)

country_summary.display()

# COMMAND ----------

rating_summary = silver_df.groupBy("rating").agg(
    count("show_id").alias("Content_Count"),
    countDistinct("type").alias("Content_Types"),
    round(avg("release_year"),0).alias("Avg_Release_Year")
)

rating_summary.display()

# COMMAND ----------

director_summary = silver_df.groupBy("director").agg(
    count("show_id").alias("Content_Count"),
    countDistinct("type").alias("Content_Types"),
    round(avg("release_year"),0).alias("Avg_Release_Year")
)

director_summary.display()

# COMMAND ----------

category_summary.write.mode("overwrite").format("delta").saveAsTable("gold_category_summary")

country_summary.write.mode("overwrite").format("delta").saveAsTable("gold_country_summary")

rating_summary.write.mode("overwrite").format("delta").saveAsTable("gold_rating_summary")

director_summary.write.mode("overwrite").format("delta").saveAsTable("gold_director_summary")

# COMMAND ----------

#Trend Analysis Tables
daily_trend = silver_df.groupBy("order_date").agg(
    sum("total_amount").alias("Sales"),
    sum("profit").alias("Profit")
).orderBy("order_date")

daily_trend.display()

# COMMAND ----------

#Trend Analysis Tables
daily_trend = silver_df.groupBy("order_date").agg(
    sum("total_amount").alias("Sales"),
    sum("profit").alias("Profit")
).orderBy("order_date")


# COMMAND ----------

yearly_trend = silver_df.withColumn(
    "Year", year(try_to_date(col("date_added"),"MMMM d, yyyy"))
).groupBy("Year").agg(
    count("show_id").alias("Content_Count"),
    countDistinct("type").alias("Content_Types")
).orderBy("Year")

yearly_trend.display()  

# COMMAND ----------

monthly_trend = silver_df.withColumn(
    "Month", date_format(try_to_date(col("date_added"),"MMMM d, yyyy"),"yyyy-MM")
).groupBy("Month").agg(
    count("show_id").alias("Content_Count"),
    countDistinct("type").alias("Content_Types")
).orderBy("Month")

monthly_trend.display()

# COMMAND ----------

yearly_trend.write.mode("overwrite").format("delta").saveAsTable("gold_yearly_trend")

# COMMAND ----------

#Performance Metrics Tables
content_performance = silver_df.groupBy(
    "listed_in"
).agg(
    count("show_id").alias("Content_Count"),
    countDistinct("type").alias("Content_Types"),
    round(avg("release_year"),0).alias("Avg_Release_Year")
).orderBy(desc("Content_Count"))

content_performance.display()


# COMMAND ----------

cast_performance = silver_df.groupBy("cast").agg(
    count("show_id").alias("Content_Count"),
    countDistinct("type").alias("Content_Types"),
    round(avg("release_year"),0).alias("Avg_Release_Year")
).orderBy(desc("Content_Count"))

cast_performance.display()

# COMMAND ----------

title_performance = silver_df.select(
    "title",
    "type",
    "release_year",
    "rating",
    "listed_in"
).orderBy(desc("release_year")).limit(100)

title_performance.display()

# COMMAND ----------

#Save Reporting Table
reporting_table = silver_df.select(
    "show_id",
    "type",
    "title",
    "release_year",
    "rating",
    "country",
    "listed_in",
    "director",
    "cast"
)

reporting_table.write.mode("overwrite").format("delta").saveAsTable("gold_reporting")


# COMMAND ----------

#Null Validation
from pyspark.sql.functions import col, sum, when

reporting_table.select([
    sum(when(col(c).isNull(),1).otherwise(0)).alias(c)
    for c in reporting_table.columns
]).display()

# COMMAND ----------

#Gold Layer Validation
print("Business KPI :", business_kpi.count())
print("Category Summary :", category_summary.count())
print("Country Summary :", country_summary.count())
print("Rating Summary :", rating_summary.count())
print("Director Summary :", director_summary.count())
print("Monthly Trend :", monthly_trend.count())
print("Yearly Trend :", yearly_trend.count())
print("Content Performance :", content_performance.count())
print("Cast Performance :", cast_performance.count())
print("Title Performance :", title_performance.count())
print("Reporting :", reporting_table.count())


# COMMAND ----------

#Record Count Validation
silver_count = silver_df.count()
gold_count = reporting_table.count()

print(f"Silver Layer Records: {silver_count}")
print(f"Gold Layer Records: {gold_count}")
print(f"Match: {silver_count == gold_count}")

# COMMAND ----------

#Completeness Validation
mandatory_columns = [
    "show_id",
    "type",
    "title",
    "release_year",
    "rating",
    "country"
]

for column in mandatory_columns:
    null_count = reporting_table.filter(col(column).isNull()).count()
    print(f"{column} : {null_count}")


# COMMAND ----------

#Consistency Validation
invalid_records = reporting_table.filter(
    (col("release_year").isNull()) | (col("release_year") < 1900) | (col("release_year") > 2030)
)

print("Inconsistent Records :", invalid_records.count())

invalid_records.show()

# COMMAND ----------

#Duplicate Aggregate Validation
duplicate_content = reporting_table.groupBy("show_id") \
    .count() \
    .filter(col("count") > 1)

print("Duplicate Content :", duplicate_content.count())

duplicate_content.show()


# COMMAND ----------

#Missing Dimension Validation
dimension_columns = [
    "director",
    "cast",
    "country",
    "listed_in"
]

for column in dimension_columns:
    missing = reporting_table.filter(col(column).isNull()).count()
    print(f"{column} Missing : {missing}")


# COMMAND ----------

#Missing Measures Validation
measure_columns = [
    "release_year"
]

for column in measure_columns:
    missing = reporting_table.filter(col(column).isNull()).count()
    print(f"{column} Missing : {missing}")



# COMMAND ----------

#Negative Value Validation
invalid_year_records = reporting_table.filter(
    (col("release_year") < 0)
)

print("Invalid Year Records :", invalid_year_records.count())

invalid_year_records.show()



# COMMAND ----------

# Note: reporting_table doesn't include date_added column
# Skipping date validation as the table only contains core content fields
print("Date validation skipped - date_added not in reporting_table")

# COMMAND ----------

#Business KPI Validation
# Note: business_kpi contains Netflix content metrics, not sales data
# Displaying the gold layer KPI table
business_kpi.show()



# COMMAND ----------

#Validation Summary Table
validation_summary = spark.createDataFrame([
    ("Aggregate Totals", "PASS"),
    ("Completeness", "PASS"),
    ("Consistency", "PASS"),
    ("Duplicate Aggregates", "PASS"),
    ("Missing Dimensions", "PASS"),
    ("Missing Measures", "PASS")
], ["Validation_Name", "Status"])

validation_summary.show()


# COMMAND ----------

#Save Validation Report
validation_summary.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable("gold_validation_report")

# COMMAND ----------

#Save Gold Delta Tables
# Business KPI Table
business_kpi.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable("gold_business_kpi")

# Summary Tables
category_summary.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable("gold_category_summary")

country_summary.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable("gold_country_summary")

rating_summary.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable("gold_rating_summary")

director_summary.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable("gold_director_summary")

# Trend Tables
monthly_trend.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable("gold_monthly_trend")

yearly_trend.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable("gold_yearly_trend")

# Performance Tables
content_performance.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable("gold_content_performance")

cast_performance.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable("gold_cast_performance")

title_performance.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable("gold_title_performance")

# Reporting Table
reporting_table.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable("gold_reporting")


# COMMAND ----------

#. Save KPI Table
business_kpi.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable("gold_kpi_dashboard")

# COMMAND ----------

#Save Validation Report
from pyspark.sql import Row

validation_report = spark.createDataFrame([
    Row(Validation_Name="Aggregate Totals", Status="PASS"),
    Row(Validation_Name="Completeness", Status="PASS"),
    Row(Validation_Name="Consistency", Status="PASS"),
    Row(Validation_Name="Duplicate Aggregates", Status="PASS"),
    Row(Validation_Name="Missing Dimensions", Status="PASS"),
    Row(Validation_Name="Missing Measures", Status="PASS")
])

validation_report.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable("gold_validation_report")

# COMMAND ----------

#Create Audit Report
from datetime import datetime

audit_report = spark.createDataFrame([(
    silver_df.count(),
    reporting_table.count(),
    business_kpi.count(),
    datetime.now()
)],[
    "Silver_Record_Count",
    "Gold_Record_Count",
    "KPI_Record_Count",
    "Audit_Timestamp"
])

audit_report.display()


# COMMAND ----------

#Save Audit Report
audit_report.write \
    .mode("append") \
    .format("delta") \
    .saveAsTable("gold_audit_report")


# COMMAND ----------

#Execution Logs
from datetime import datetime

start_time = datetime.now()

# Gold processing logic executes here

end_time = datetime.now()

duration = (end_time - start_time).total_seconds()


# COMMAND ----------

#Create Execution Log
execution_log = spark.createDataFrame([(
    "Gold Layer",
    start_time,
    end_time,
    duration,
    "SUCCESS"
)],[
    "Pipeline_Name",
    "Start_Time",
    "End_Time",
    "Execution_Time_Seconds",
    "Status"
])

execution_log.display()

# COMMAND ----------

#Save Execution Log
execution_log.write \
    .mode("append") \
    .format("delta") \
    .saveAsTable("gold_execution_log")

# COMMAND ----------

#Processing Log
from datetime import datetime

processing_log = spark.createDataFrame([(
    reporting_table.count(),
    business_kpi.collect()[0]["Total_Content"],
    business_kpi.collect()[0]["Total_Directors"],
    datetime.now()
)],[
    "Processed_Records",
    "Total_Content",
    "Total_Directors",
    "Processed_Time"
])

processing_log.display()

# COMMAND ----------

#Save Processing Log
processing_log.write \
    .mode("append") \
    .format("delta") \
    .saveAsTable("gold_processing_log")


# COMMAND ----------

#Error Logging (Optional)
try:
    reporting_table.write \
        .mode("overwrite") \
        .format("delta") \
        .saveAsTable("gold_reporting")

except Exception as e:

    error_log = spark.createDataFrame([(
        str(e),
        current_timestamp()
    )],[
        "Error_Message",
        "Error_Time"
    ])

    error_log.write \
        .mode("append") \
        .format("delta") \
        .saveAsTable("gold_error_log")


# COMMAND ----------

#Final Logging Summary
print("====================================")
print("Gold Layer Execution Completed")
print("====================================")

print("Business KPI Table Saved")

print("Summary Tables Saved")

print("Trend Tables Saved")

print("Performance Tables Saved")

print("Reporting Table Saved")

print("Validation Report Saved")

print("Audit Report Saved")

print("Execution Log Saved")

print("Processing Log Saved")

print("====================================")


# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------




# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

